/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "pwa-192x192.png",
    "revision": "306b54816ec4bc010d54cd2e9a575370"
  }, {
    "url": "profil.html",
    "revision": "f8d27062771db606f6e0913cbcaf6b05"
  }, {
    "url": "logo-kafela.svg",
    "revision": "e925f0bea3871b474043327e24d5e167"
  }, {
    "url": "logo-kafela.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "index.html",
    "revision": "6049135e21beb56d2d3f837b7cb7cb16"
  }, {
    "url": "icon.svg",
    "revision": "e925f0bea3871b474043327e24d5e167"
  }, {
    "url": "firebase-config.js",
    "revision": "f181ed2e77d6673ec12c628bb14e70d4"
  }, {
    "url": "favicon.svg",
    "revision": "e925f0bea3871b474043327e24d5e167"
  }, {
    "url": "booking.html",
    "revision": "3f493f16c94292e5cf0d128c7d2767c7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "718e7d8972b208fa700ec013386e6eb7"
  }, {
    "url": "assets/index-Dx1Xx5M6.css",
    "revision": null
  }, {
    "url": "assets/index-CWsxdLhV.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "718e7d8972b208fa700ec013386e6eb7"
  }, {
    "url": "booking.html",
    "revision": "3f493f16c94292e5cf0d128c7d2767c7"
  }, {
    "url": "firebase-config.js",
    "revision": "f181ed2e77d6673ec12c628bb14e70d4"
  }, {
    "url": "icon.svg",
    "revision": "e925f0bea3871b474043327e24d5e167"
  }, {
    "url": "logo-kafela.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "logo-kafela.svg",
    "revision": "e925f0bea3871b474043327e24d5e167"
  }, {
    "url": "profil.html",
    "revision": "f8d27062771db606f6e0913cbcaf6b05"
  }, {
    "url": "pwa-192x192.png",
    "revision": "306b54816ec4bc010d54cd2e9a575370"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "8c8b205e64ca5cc307a06aa5adf51912"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b1c6dcdb194ebebfc253f2b7a58e5555"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/booking\.html/, /^\/profil\.html/, /^\/firebase-config\.js/, /^\/kflsagnd-kasir-pc\.zip/, /^\/b\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
